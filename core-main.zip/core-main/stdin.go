package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	// Create a new scanner to read from standard input
	scanner := bufio.NewScanner(os.Stdin)

	fmt.Println("Enter some text (press Ctrl+D or Ctrl+Z to end):")

	// Read input line by line
	for scanner.Scan() {
		text := scanner.Text() // Get the current line of text
		if text == "" {
			break // Exit loop if an empty line is entered
		}
		fmt.Println("You entered:", text)
	}

	if err := scanner.Err(); err != nil {
		fmt.Println("Error:", err)
	}
}

func input(message string)string {
  fmt.Print(message)
  scanner:=bufio.NewScanner(os.Stdin)
  toReturn :=""
  for scanner.Scan() {
    text := scanner.Text()
    if text== "" || text=="\n" {
      break
    }
    toReturn = toReturn + text
  }
if err := scanner.Err(); err != nil {
		fmt.Println("Error:", err)
	}
  return toReturn 
}
